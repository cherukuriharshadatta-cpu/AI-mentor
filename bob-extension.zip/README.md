# Bob 1.4 — project-aware security chat

Extract this ZIP into a folder. In Chrome or Edge, open Extensions, enable Developer mode, choose Load unpacked, and select that folder. If replacing an existing Bob installation, reload the extension and refresh your ChatGPT, Claude, or Gemini tab.

## Use

Tell Bob what you are building, then click **Project security**. Security questions also open a local assessment directly in Chat. No API key is required for this assessment. With page-reading permission, Bob uses the current conversation's user messages and visible code blocks. Without permission, it uses only what you type into Bob. The existing Use page switch also permits page context. Pausing watching stops automatic page access; turn Use page off too if previously enabled.

Each check states why it applies to your project, why it matters, and what to implement or verify. Suspected code issues include a block number, line number, and masked evidence. Preventive checks are not described as proven missing protections. Completed checklist items are omitted from the chat report.

The same conservative checks populate Checkup. A project category alone does not imply login, payments, a database, or secret keys. User statements establish features; assistant suggestions do not. Later explicit negative statements remove features. Changing conversation routes clears Bob's prior chat context.

General AI chat still uses the configured OpenRouter key. Its system context now includes the local assessment. Page context is sent to the model only when Use page is on. Local assessments do not send network requests.

## Scope

This is an English rule-based assessment of shared descriptions and visible code, not repository access or a complete security audit. Complex negation, ambiguous descriptions, or unrecognized features can need clarification. No dependency vulnerability database is queried. Code patterns indicate possible problems, not confirmed exploits. Bob cannot verify protections in unseen files. Common key patterns are masked in evidence; avoid sharing real secrets.

## Tests

Run from the extracted folder with Node.js:

```
node tests/test_engine.js
node tests/test_project_security.js
node tests/smoke.js
node tests/smoke_intro.js
node tests/test_bridge.js
```

The smoke test covers the revised evidence-driven behavior rather than the old category-based blanket checklist.
