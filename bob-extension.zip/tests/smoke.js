// Regression coverage for project-aware chat; run with node tests/smoke.js.
const h = require('./harness')({ page: { user: ['A public portfolio with no login or payments.'], pre: [] } });
(async () => {
  await h.wait(100);
  await h.click('security');
  h.check('without permission, page details are not read', !h.msgsHtml().includes('Your description'));
  h.check('missing context asks a focused question', h.msgsHtml().includes('What are you building'));
  await h.click('enable'); await h.wait(100);
  await h.click('security');
  h.check('security is delivered in chat', h.$$('panel').dataset.tab === 'chat');
  h.check('public site gets HTTPS with reasons', h.msgsHtml().includes('HTTPS') && h.msgsHtml().includes('Next step:'));
  h.check('does not invent payment protections', !h.msgsHtml().includes('Check: Check payments'));
  h.check('local assessment never calls provider', h.calls.length === 0);
  h.PAGE.user = ['Offline calculator without accounts, payments or database.'];
  await h.click('security');
  h.check('fresh page context replaces old requirements', h.msgsHtml().includes('I do not see enough evidence'));
  h.$$('input').value = 'Use Stripe payments.';
  await h.click('security');
  h.check('typed project facts affect report', h.msgsHtml().includes('payments'));
  h.check('local analysis works without key', h.calls.length === 0);
  global.location.pathname = '/c/2';
  h.PAGE.user = [];
  await h.click('security');
  h.check('new conversation forgets old project', !h.msgsHtml().includes('Stripe'));
  h.finish();
})().catch(e => { console.error(e); process.exit(1); });
